.. _reference_neal:

Reference Documentation
***********************

.. attention::

    ``dwave-neal`` is deprecated since ``dwave-ocean-sdk`` 6.1.0 in favor of
    :ref:`index_dwave_samplers` and will be removed in ``dwave-ocean-sdk`` 8.0.0.

.. toctree::
   :maxdepth: 2

   sampler
