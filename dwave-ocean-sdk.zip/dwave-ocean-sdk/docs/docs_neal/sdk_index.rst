.. _sdk_index_neal:

==========
dwave-neal
==========

.. attention::

    ``dwave-neal`` is deprecated since ``dwave-ocean-sdk`` 6.1.0 in favor of
    :ref:`index_dwave_samplers` and will be removed in ``dwave-ocean-sdk`` 8.0.0.

An implementation of a simulated annealing sampler.

.. toctree::
    :maxdepth: 1

    intro
    reference/index
    Source <https://github.com/dwavesystems/dwave-neal>
