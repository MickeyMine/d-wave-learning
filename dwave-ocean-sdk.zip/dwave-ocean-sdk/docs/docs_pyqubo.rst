.. _pyqubo:

======
pyqubo
======

A package that helps you create :term:`QUBO` and :term:`Ising` models from flexible 
mathematical expressions.

For more information, see `pyQUBO documentation <https://pyqubo.readthedocs.io>`_.

