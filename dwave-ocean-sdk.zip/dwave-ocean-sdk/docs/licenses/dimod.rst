=====
dimod
=====

.. include:: ../docs_dimod/LICENSE
