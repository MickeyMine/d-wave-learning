==================
dwave-optimization
==================

.. include:: ../docs_optimization/LICENSE
