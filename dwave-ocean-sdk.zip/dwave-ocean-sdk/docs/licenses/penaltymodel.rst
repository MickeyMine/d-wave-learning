============
penaltymodel
============

.. include:: ../docs_penalty/LICENSE
